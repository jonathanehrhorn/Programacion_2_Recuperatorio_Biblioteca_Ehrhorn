package recuperatorioparcial;

public enum Genero {
    FICCION,
    NOFICCION,
    CIENCIA,
    HISTORIA
}
