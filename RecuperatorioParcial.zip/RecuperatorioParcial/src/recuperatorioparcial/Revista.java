package recuperatorioparcial;

public class Revista extends Publicacion implements Leible {
    private int edicion;

    public Revista(int edicion, String titulo, int anio) {
        super(titulo, anio);
        this.edicion = edicion;
    }

    @Override
    public void leer() {
        System.out.println("Usted lee una revista");
    }

    @Override
    public String toString() {
        return "Revista{" + "edicion=" + edicion + super.toString();
    }
    
    
}
