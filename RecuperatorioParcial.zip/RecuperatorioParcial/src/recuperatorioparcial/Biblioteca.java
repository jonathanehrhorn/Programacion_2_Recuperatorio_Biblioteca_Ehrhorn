package recuperatorioparcial;

import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    private List<Publicacion> publicaciones;

    public Biblioteca() {
        this.publicaciones = new ArrayList<>();
    }

    public void agregarPublicacion(Publicacion publicacion) {
        if (this.publicaciones.contains(publicacion)) {
            throw new LibroExistenteException();
        }
        this.publicaciones.add(publicacion);
    }

    public void mostrarPublicaciones() {
        for (Publicacion publicacion : this.publicaciones) {
            System.out.println(publicacion);
        }
    }

    public void leerPublicaciones() {
        for (Publicacion publicacion : this.publicaciones) {
            if(publicacion instanceof Leible p) {
                p.leer();
            } else {
                System.out.println("Las ilustraciones no se leen");
            }
        }
    }
    
}
