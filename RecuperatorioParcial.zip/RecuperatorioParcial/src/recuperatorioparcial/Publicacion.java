package recuperatorioparcial;

import java.util.Objects;

public class Publicacion {
    private String titulo;
    private int anio;

    public Publicacion(String titulo, int anio) {
        this.titulo = titulo;
        this.anio = anio;
    }
    
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    public String getTitulo(){
        return titulo;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }
    
    public int getAnio(){
        return anio;
    }

    @Override
    public int hashCode() {
        return Objects.hash(titulo, anio);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj instanceof Publicacion other) {
            return titulo.equals(other.titulo) && anio == other.anio;
        }
        return false;
    }
    
    @Override
    public String toString() {
        return ", titulo=" + titulo + ", anio=" + anio + '}';
    }
    
}
