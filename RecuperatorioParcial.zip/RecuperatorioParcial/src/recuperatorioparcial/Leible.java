package recuperatorioparcial;

public interface Leible {

    void leer();

}
