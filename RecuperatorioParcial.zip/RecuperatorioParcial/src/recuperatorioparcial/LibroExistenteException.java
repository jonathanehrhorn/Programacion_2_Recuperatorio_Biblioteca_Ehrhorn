package recuperatorioparcial;

public class LibroExistenteException extends RuntimeException {
    private static final String MESSAGE = "No se puede registrar dos veces el mismo libro";
    
    public LibroExistenteException() {
        super(MESSAGE);
    }
}
