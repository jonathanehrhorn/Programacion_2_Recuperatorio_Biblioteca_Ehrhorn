package recuperatorioparcial;

public class RecuperatorioParcial {

    public static void main(String[] args) {
        Biblioteca b1 = new Biblioteca();
        
        Publicacion p1 = new Libro("Isaac Asimov", Genero.FICCION, "Fundacion", 1954);
        
        b1.agregarPublicacion(p1);
        
        b1.leerPublicaciones();
        
        b1.mostrarPublicaciones();
    }
    
}
