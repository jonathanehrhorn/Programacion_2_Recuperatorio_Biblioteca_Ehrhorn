package recuperatorioparcial;

public class Libro extends Publicacion implements Leible {
    private String autor;
    public Genero genero;

    public Libro(String autor, Genero genero, String titulo, int anio) {
        super(titulo, anio);
        this.autor = autor;
        this.genero = genero;
    }

    @Override
    public void leer() {
        System.out.println("Usted lee un libro");
    }

    @Override
    public String toString() {
        return "Libro{" + "autor=" + autor + ", genero=" + genero + super.toString();
    }
    
    

    
    
    
}
